#!/usr/bin/env python
#coding:utf-8

import pygtk
pygtk.require("2.0")
import gtk
import os
import time
import subprocess
import shutil
import hashlib
import socket
import sys
import re



class TU:
    def show_msg(self, msg, type=gtk.MESSAGE_INFO, buttons=gtk.BUTTONS_YES_NO):
        msgBox = None
        try:
            msgBox = gtk.MessageDialog(parent = None, 
                                type = type, 
                                buttons = buttons, 
                                message_format = msg)
            msgBox.set_property("text", "ThinclST Updater")
            msgBox.set_property("secondary-text", msg)
            if msgBox.run() == gtk.RESPONSE_NO:
                return 0
            else:
                return 1
        finally:
            if msgBox is not None:
                msgBox.destroy()
    

    # コマンド実行 共通関数
    def exec_cmd(self, cwd, cmdline):
        # cwd: 作業ディレクトリ
        # cmdline: 実行コマンド
        print("【コマンド】" + cmdline)

        self.proc = subprocess.Popen(cmdline, shell=True, cwd=cwd, stdin=subprocess.PIPE,
                                     stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                                     close_fds=True)
        (self.stdouterr, self.stdin) = (self.proc.stdout, self.proc.stdin)  # ファイルオブジェクト

def main():
    tool=TU()
    ret=tool.show_msg("test")
    #gtk.main()
    sys.exit(ret)

if __name__ == "__main__":
    main()


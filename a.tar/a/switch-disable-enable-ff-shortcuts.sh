#!/bin/bash

SWITCH_FLAG=$1
ORG_OMNI=/usr/lib/firefox-esr/browser/omni.ja
E_OMNI=/usr/lib/firefox-esr/browser/omni.ja.limit
D_OMNI=/usr/lib/firefox-esr/browser/omni.ja.diskeyshortcut

ps -ef |grep firefox-esr | grep -v grep
if [ $? -eq 0 ]; then
  python /home/thinclstuser/msg.py 
  echo $?
fi
rm -rf /home/thinclstuser/.cache/mozilla/firefox-esr

if [ $SWITCH_FLAG -eq 1 ]; then
  cp $E_OMNI $ORG_OMNI
else
  cp $D_OMNI $ORG_OMNI
fi

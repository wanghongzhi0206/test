#!/bin/bash

DEB_FILE_PATH=/tmp/files
cp -a /usr/lib/firefox-esr/browser/omni.ja /usr/lib/firefox-esr/browser/omni.ja.limit
mkdir /tmp/omni
unzip -d /tmp/omni /usr/lib/firefox-esr/browser/omni.ja

cp $DEB_FILE_PATH/browser.xhtml /tmp/omni/chrome/browser/content/browser/browser.xhtml

cd /tmp/omni
zip -r omni.ja.diskeyshortcut *
mv omni.ja.diskeyshortcut /usr/lib/firefox-esr/browser/


rm -fr /tmp/omni

#!/bin/sh -x

# base image
BASE_ISO=/mnt/linux/ubuntu-20.04.4-desktop-amd64.iso

## clean uck and ~/tmp
uck-remaster-clean
rm -rf ~/tmp/*

## unpack iso
uck-remaster-unpack-iso ${BASE_ISO}

## unpack rootfs
uck-remaster-unpack-rootfs

#!/bin/sh -x

echo
echo "Remastering the dvd..."
echo "======================================"

cd ~/tmp
mkdir initrd-tmp
cd initrd-tmp
cp ../remaster-iso/casper/initrd .
unmkinitramfs initrd .


CONF_DIR=/home/thin-dev/desktop-conf
cd ${CONF_DIR}
./mk-initrd.sh

cd ~/tmp/initrd-tmp
touch myinitrd
cd early
find . -print0 | cpio --null --create --format=newc > ../myinitrd
# find . -print0 | cpio -R 0:0 -o -H newc > ../myinitrd
cd ../early2
find kernel -print0 | cpio --null --create --format=newc >> ../myinitrd
# find kernel -print0 | cpio -R 0:0 -o -H newc >> ../myinitrd
cd ../main
find . | cpio --create --format=newc | lz4 -9 -l >> ../myinitrd
# find . | cpio -R 0:0 -o -H newc | lz4 -9 -l >> ../myinitrd

cp ../myinitrd ~/tmp/remaster-iso/casper/initrd

echo
echo "Editing boot options and graphics..."
echo "======================================"


cd ${CONF_DIR}
cp -a isolinux/* ~/tmp/remaster-iso/isolinux/
cp -a boot/* ~/tmp/remaster-iso/boot/


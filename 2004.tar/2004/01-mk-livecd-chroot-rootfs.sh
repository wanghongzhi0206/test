#!/bin/sh -x

## after exec command uck-remaster-chroot-rootfs

# livecd
LIVECD_DIR=/tmp/ST-7.8.0-v00.00U/livecd

sed -i  s/"#exec update-grub"/"exec update-grub"/g /etc/kernel/postinst.d/zz-update-grub
sed -i  s/"#exec update-grub"/"exec update-grub"/g /etc/kernel/postrm.d/zz-update-grub

#export http_proxy=http://proxygate2.nic.nec.co.jp:8080
#export https_proxy=http://proxygate2.nic.nec.co.jp:8080

#■ package update
cp -a /etc/apt/sources.list.save /etc/apt/sources.list
apt-get update
apt list --upgradable > ${LIVECD_DIR}/apt-list-upgradable.txt
apt-get -y upgrade
sleep 5

apt-get purge -y ubiquity ubiquity-casper ubiquity-frontend-gtk ubiquity-slideshow-ubuntu ubiquity-ubuntu-artwork
apt-get purge -y libreoffice-common
apt-get purge -y  thunderbird totem rhythmbox simple-scan gnome-mahjongg aisleriot gnome-mines cheese transmission-common gnome-sudoku

cd ${LIVECD_DIR}


#■dpkg list
dpkg -l > ${LIVECD_DIR}/dpkg-list.txt
cp -a /etc/apt/sources.list.org /etc/apt/sources.list


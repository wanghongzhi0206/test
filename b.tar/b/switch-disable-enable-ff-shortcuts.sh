#!/bin/bash

SWITCH_FLAG=$1
ORG_OMNI=/usr/lib/firefox-esr/browser/omni.ja
E_OMNI=/usr/lib/firefox-esr/browser/omni.ja.limit
D_OMNI=/usr/lib/firefox-esr/browser/omni.ja.diskeyshortcut

chown 999.999 $ORG_OMNI
chown 999.999 $D_OMNI
chown 999.999 $E_OMNI

rm -rf /home/thinclstuser/.cache/mozilla/firefox-esr

if [ $SWITCH_FLAG -eq 1 ]; then
  cp $E_OMNI $ORG_OMNI
else
  cp $D_OMNI $ORG_OMNI
fi


python /home/thinclstuser/msg.py $SWITCH_FLAG
